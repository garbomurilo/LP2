﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pnotebook02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {

        }

        private int GetI()
        {
            return i;
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int i, j;
            i = 0;
            j = 0;

            for (i = 0; i < 1; i++)
            {
                string linha = Interaction.InputBox("Digite o nome do notebook");
                for (j = 0; j < 2; j++)
                {
                    string Coluna = Interaction.InputBox("Digite o nome da loja e o valor do notebook");
                }
            }
            lstboxPrecos.Text = Linha.ToString()
        }
    }
}
